import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Main {
	private int count = 0;
	private Random rand = new Random();
	private int num = 0;

	public static void main(String[] args) {

		Main main = new Main();

		main.run();

	}

	public void run(){
		count = 0;
		boolean isMatch = false;

		//乱数決定
		num = rand.nextInt(100)+1;

		System.out.println("HIGH & LOW GAME");
		try(Scanner sc = new Scanner(System.in)){

			while(!isMatch){
				int inputNum = getInputNum(sc);
				if( inputNum != -1 ){
					isMatch = isMatch(inputNum);
					count++;
				}
			}

			System.out.println(count+"回目でクリア");

		}
	}

	private int getInputNum(Scanner sc){
		int num = 0;
		try{
			num = sc.nextInt();
		}catch(InputMismatchException  e){
			System.out.println("数値入力しろ！");
			num = -1;
			sc.next();
		}

		return num;
	}

	private boolean isMatch(int inputNum){
		boolean result = false;

		if( inputNum > num ){
			System.out.println("HIGH");
		}else if( inputNum < num ){
			System.out.println("LOW");

		}else{
			System.out.println("OK!");
			result = true;
		}

		return result;
	}
}
