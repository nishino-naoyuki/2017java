package exceptionsample;

public class JssJk2902 {

	public static void main(String[] args) {
		int[] arry = new int[2];

		try{
			int c = arry[3];
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("例外発生！");
		}

		System.out.println("プログラム終了");
	}
}
