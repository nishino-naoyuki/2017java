package exceptionsample;

class SimpleClass {
	public void doSomething(){
		int[] array = new int[3];
		array[10] = 99;
		System.out.println("doSomethingを終了します");
	}
}
public class ExceptionExample5 {

	public static void main(String[] args) {
		SimpleClass obj = new SimpleClass();
		try{
			obj.doSomething();

		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("例外をキャッチしました");
			e.printStackTrace();
		}

	}

}
