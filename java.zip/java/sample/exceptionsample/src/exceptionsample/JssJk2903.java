package exceptionsample;

public class JssJk2903 {

	public static void main(String[] args) {

		try{
			int c = Integer.parseInt(args[0]);
			System.out.println(c);
		}catch(NumberFormatException e){
			System.out.println("変換できない！");

		}
	}
}
