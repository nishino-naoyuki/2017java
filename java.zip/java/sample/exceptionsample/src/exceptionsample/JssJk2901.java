package exceptionsample;

public class JssJk2901 {

	public static void main(String[] args) {
		int a = 1;
		int b = 0;

		try{
			int c = a/b;
		}catch(ArithmeticException e){
			System.out.println("例外発生！");

		}finally{
			System.out.println("finallyが実行されました！");

		}
	}
}
