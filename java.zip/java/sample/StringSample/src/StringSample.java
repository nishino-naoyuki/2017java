public class StringSample {

	public static void main(String[] args) {
		//MyClass myc = new MyClass();

		//myc.printMassage();
	}

}
