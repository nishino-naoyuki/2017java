
public class JssSt1402 {

	public static void main(String[] args) {
		int data = Integer.parseInt(args[0]);

		if( data == 1 || data == 2 ){
			System.out.println("渡されたのは１か２です");
		}else{
			System.out.println("渡されたのは、１と２以外です");

		}
	}

}
