
public class JssSt1406 {

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		JssSt1406 obj = new JssSt1406();

		System.out.println(obj.kaijo(num));
	}

	public int kaijo(int num){
		int total = num;

		for(int i = num-1; i > 0; i-- ){
			total *= i;
		}

		return total;
	}
}
