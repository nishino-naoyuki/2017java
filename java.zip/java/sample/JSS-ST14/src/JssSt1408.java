
public class JssSt1408 {

	public static void main(String[] args) {
		Mario m = new FireMario();

		m.display();
	}

}
