
public class Mario {
	public void display(){
		System.out.println("Mario");
	}
}
