
public class JssSt1404 {

	public static void main(String[] args) {
		int saiA1 = Integer.parseInt(args[0]);
		int saiA2 = Integer.parseInt(args[1]);
		int saiB1 = Integer.parseInt(args[2]);
		int saiB2 = Integer.parseInt(args[3]);

		int scoreA = getScore(saiA1,saiA2);
		int scoreB = getScore(saiB1,saiB2);;

		System.out.println("Aさんの点数:"+scoreA+"点");
		System.out.println("Bさんの点数:"+scoreB+"点");
		if( scoreA == scoreB ){
			System.out.println("引き分け");
		}else if(scoreA > scoreB){
			System.out.println("Aさんの勝利");
		}else{
			System.out.println("Bさんの勝利");
		}
	}

	public static int getScore(int sai1,int sai2){
		int socre = 0;
		int[] zoroScore = {20,15,16,17,18,19};

		if( sai1 == sai2 ){
			socre = zoroScore[sai1-1];
		}else{
			socre = sai1+sai2;
		}

		return socre;
	}
}
