
public class JssSt1407 {

	public static void main(String[] args) {
		Mario m = new Mario();

		m.display();
	}

}
