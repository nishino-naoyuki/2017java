
public class JssSt1403 {

	public static void main(String[] args) {
		int sai1 = Integer.parseInt(args[0]);
		int sai2 = Integer.parseInt(args[1]);

		if( sai1 == 1 && sai2 == 1 ){
			System.out.println("ピンゾロ");
		}else if( sai1 == sai2 ){
			System.out.println("ゾロ目！");
		}else{
			System.out.println("値は"+sai1+"と"+sai2+"です");
		}

	}

}
