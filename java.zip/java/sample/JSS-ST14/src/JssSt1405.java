
public class JssSt1405 {

	public static void main(String[] args) {

		String[] strings = getStrings(args[0]);

		for(String msg : strings){
			System.out.println(msg);
		}

	}

	private static String[] getStrings(String src){
		if( src == null ){
			return new String[0];
		}

		return src.split(",");
	}
}
