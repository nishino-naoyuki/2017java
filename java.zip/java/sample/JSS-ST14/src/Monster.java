
public class Monster {

}
