
public class FireMario extends Mario {
	public void display(){
		System.out.println("FireMario");
	}

}
