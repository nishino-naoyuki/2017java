package example;

import java.util.ArrayList;

public class ArrayListExample5 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();

		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		list.add("ddd");

		///////////////////////////////////////////
		//ここで2つ目の「bbb」を削除する必要が出てきた！
		list.remove(1);

		System.out.println("length="+list.size());
		for(int i = 0; i < list.size();i++){
			System.out.println(list.get(i));
		}

	}

}

