package example;

import java.util.ArrayList;

public class ArrayListExample2 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();

		list.add("aaa");
		list.add("bbb");
		list.add("ccc");

		///////////////////////////////////////////
		//ここで4つ目に「ddd」を追加する必要が出てきた！
		list.add("ddd");

		System.out.println("length="+list.size());
		for(int i = 0; i < list.size();i++){
			System.out.println(list.get(i));
		}

	}

}

