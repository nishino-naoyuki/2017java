package example;

public class ArrayListExample3 {

	public static void main(String[] args) {
		String[] arry1  = new String[4];

		arry1[0] = "aaa";
		arry1[1] = "bbb";
		arry1[2] = "ccc";
		arry1[3] = "ddd";

		///////////////////////////////////////////
		//ここで2つ目の「bbb」を削除する必要が出てきた！
		for(int i=1; i < 3 ; i++){
			arry1[i] = arry1[i+1];
		}
		arry1[3] = "";

		System.out.println("length="+arry1.length);
		for(int i = 0; i < arry1.length;i++){
			System.out.println(arry1[i]);
		}

	}

}

