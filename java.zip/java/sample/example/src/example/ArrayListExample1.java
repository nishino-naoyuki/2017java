package example;

public class ArrayListExample1 {

	public static void main(String[] args) {
		String[] arry1  = new String[3];

		arry1[0] = "aaa";
		arry1[1] = "bbb";
		arry1[2] = "ccc";

		///////////////////////////////////////////
		//ここで4つ目に「ddd」を追加する必要が出てきた！
		String[] arry2 = new String[4];
		//arry1の内容をarry2にコピーする
		System.arraycopy(arry1, 0, arry2, 0, arry1.length);
		arry2[3] = "ddd";

		System.out.println("length="+arry2.length);
		for(int i = 0; i < arry2.length;i++){
			System.out.println(arry2[i]);
		}

	}

}

