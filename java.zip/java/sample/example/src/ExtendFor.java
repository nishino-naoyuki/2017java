import java.util.ArrayList;

public class ExtendFor {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();

		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		list.add("ddd");

		for( String param : list ){
			System.out.println(param);
		}

		for( int i = 0; i < list.size(); i++ ){
			String param = list.get(i);
			System.out.println(param);
		}
	}
}
