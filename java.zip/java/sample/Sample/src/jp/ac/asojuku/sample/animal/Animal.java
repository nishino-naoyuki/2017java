package jp.ac.asojuku.sample.animal;

public class Animal {
	public void call(){
		System.out.println("Animalです");
	}
}

