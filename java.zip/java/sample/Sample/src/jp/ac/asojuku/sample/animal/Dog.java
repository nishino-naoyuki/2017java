package jp.ac.asojuku.sample.animal;

public class Dog extends Animal {
	public void call(){
		System.out.println("Dogです");
	}
}

