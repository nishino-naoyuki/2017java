package jp.ac.asojuku.sample.main;

import jp.ac.asojuku.sample.animal.Dog;

public class Main {

	public static void main(String[] args) {
		Dog dog = new Dog();

		dog.call();
	}

}

