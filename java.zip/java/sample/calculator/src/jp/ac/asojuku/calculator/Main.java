package jp.ac.asojuku.calculator;

public class Main {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
