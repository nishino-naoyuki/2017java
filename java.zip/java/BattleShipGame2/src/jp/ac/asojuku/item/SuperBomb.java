package jp.ac.asojuku.item;

public class SuperBomb extends Bomb {

	public SuperBomb(int x, int y) {
		super(x, y);
		power = 2;
	}

}
