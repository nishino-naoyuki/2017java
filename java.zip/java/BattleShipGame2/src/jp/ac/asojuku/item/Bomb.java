/**
 *
 */
package jp.ac.asojuku.item;

/**
 * 爆弾
 * @author nishino
 *
 */
public class Bomb {
	protected int power;
	private int x;
	private int y;

	public Bomb(int x,int y){
		power = 1;
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}
}
