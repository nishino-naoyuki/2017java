/**
 *
 */
package jp.ac.asojuku.battleship.ship;

/**
 * 戦艦クラス
 * @author nishino
 *
 */
public class BattleShip {
	private int posX;
	private int posY;
	protected int life;
	protected String name;
	public final static int STATUS_OK = 0;
	public final static int STATUS_DOWN = 0;

	public BattleShip(int x,int y){
		posX = x;
		posY = y;
		life = 1;
		name = "Normal";
	}

	public String getName(){
		return name;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	/**
	 * ダメージを受ける
	 * @param point
	 */
	public void damaged(int point){
		life -= point;
		if( life < 0 ){
			life = 0;
		}
	}

	/**
	 * 現在この船が沈没しているかどうか
	 * @return
	 */
	public boolean isDown(){
		return ( life <= 0 ? true:false);
	}


}
