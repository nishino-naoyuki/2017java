package jp.ac.asojuku.battleship;

import java.util.Random;
import java.util.Scanner;

import jp.ac.asojuku.battleship.ship.BattleShip;
import jp.ac.asojuku.battleship.ship.SuperBattleShip;
import jp.ac.asojuku.item.Bomb;

public class GameManage {
	private final int MAPX = 5;
	private final int MAPY = 5;
	private final int SHIPNUM = 3;
	//戦艦の位置。nullは戦艦が無いことを示す
	private BattleShip[][] map =
	{
		{null,null,null,null,null},
		{null,null,null,null,null},
		{null,null,null,null,null},
		{null,null,null,null,null},
		{null,null,null,null,null},
	};


	public void gameMain(Scanner s){
		//マップの初期化
		initMap();

		boolean isAllClear = false;
		//メインループ
		while (isAllClear != true){
			//爆弾の位置を入力
			Bomb b = inputBombPos(s);
			if( b == null ){
				continue;
			}
			//ヒット、波高しチェック
			checkBattleShip(b);
			//全て破壊したかをチェック
			int shipNum = getShipNum();
			if( shipNum == 0 ){
				//全て破壊したのならオールクリア
				isAllClear = true;
			}else{
				System.out.println("戦艦残り："+shipNum);
			}
		}

		System.out.println("勝利");
	}

	/**
	 * マップの初期化
	 */
	private void initMap(){
		Random rnd = new Random();
		int shipNum = 0;
		int superShipNum = 0;

		//指定数分、戦艦を配置する
		while(shipNum < SHIPNUM){
			//戦艦の位置をランダムで決定する
			int x = rnd.nextInt(MAPX);
			int y = rnd.nextInt(MAPY);

			if( map[x][y] == null ){
				//マップ上にまだ戦艦が無い場合配置する
				if( rnd.nextInt(3) == 0){
					//1/3の確率でスーパー戦艦にする
					map[x][y] = new SuperBattleShip(x,y);
					superShipNum++;
				}else{
					map[x][y] = new BattleShip(x,y);
				}
				shipNum++;
			}
		}

		//表示する
		System.out.println("[戦艦の数]\n通常戦艦："+(shipNum-superShipNum)+"\nスーパー戦艦："+superShipNum);
	}


	/**
	 * 爆弾位置の入力
	 * @param s
	 * @return
	 */
	private Bomb inputBombPos(Scanner s){
		Bomb b = null;
		try{
			System.out.println("爆弾の位置を入力してください（１～３）");
			System.out.print("x=");
			int x = s.nextInt();
			System.out.print("y=");
			int y = s.nextInt();

			//入力値チェック
			if( ( x < 1 || x > MAPX) || ( y < 1 || y > MAPY) ){
				System.out.println("１～３の範囲で入力してください");
				return null;
			}
			x--;
			y--;
			//爆弾オブジェクトを生成
			//ポイント：例えばここでBombクラスを継承した
			//SuperBombなどを生成すると強力な爆弾など使える
			b = new Bomb(x,y);

		}catch(Exception e){
			System.out.println("数値を入力してください");
		}

		return b;
	}

	/**
	 * 波高し、命中のチェック
	 * @param b
	 */
	private void checkBattleShip(Bomb b){
		int bx = b.getX();
		int by = b.getY();

		//波高しのチェック
		boolean isNamitakashi = isNamiTakashi(b);

		//命中したかのチェック
		boolean isMeityu = false;
		boolean isDown = false;
		if( map[bx][by] != null &&
			map[bx][by].isDown() == false){
			isMeityu = true;
			//船にダメージを与える
			map[bx][by].damaged(b.getPower());
			isDown = map[bx][by].isDown();
		}

		//結果を表示
		if( isNamitakashi ){
			System.out.println("波高し！");
		}
		if( isMeityu ){
			System.out.print("命中した！");
			if( isDown ){
				System.out.print("戦艦を倒した！");
			}
			System.out.println();
		}
	}

	/**
	 * 波隆かどうかをチェックする
	 * @param b　爆弾オブジェクト
	 * @return
	 */
	private boolean isNamiTakashi(Bomb b){

		int bx = b.getX();
		int by = b.getY();
		//爆弾の前後左右に船があるかをチェックする
		int[][] checkRange = {
				{1,0},{-1,0},{0,1},{0,-1}
		};

		//波高しのチェック
		boolean isNamitakashi = false;
		for( int[] range : checkRange){
			int chkX = bx + range[0];
			int chkY = by + range[1];

			if(
				( chkX < 0 || chkX >= MAPX) ||
				( chkY < 0 || chkY >= MAPY) ){
				//チェック対象が範囲外ならノーチェック
				continue;
			}

			if( map[chkX][chkY] != null &&
				map[chkX][chkY].isDown() == false){
				isNamitakashi = true;
			}
		}

		return isNamitakashi;
	}

	/**
	 * 船の数を数える
	 * @return
	 */
	private int getShipNum(){
		int shipnum = 0;

		for( BattleShip bs[] : map ){
			for( BattleShip b : bs){
				if( b != null && b.isDown() == false){
					shipnum ++;
				}
			}
		}

		return shipnum;
	}

}
