/**
 *
 */
package jp.ac.asojuku.battleship.ship;

/**
 * ｽｰﾊﾟ
 * @author nishino
 *
 */
public class SuperBattleShip extends BattleShip {

	public SuperBattleShip(int x, int y) {
		super(x, y);
		name = "SuperShip";
		life = 3;
	}

}
