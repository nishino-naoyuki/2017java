package jp.ac.asojuku.sanmoku;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner s = null;

		try{
			s = new Scanner(System.in);

			GameManage m = new GameManage();

			m.gameMain(s);

		}finally{
			//Scannerをクローズ
			if( s != null ){
				s.close();
			}
		}

	}

}
