package jp.ac.asojuku.sanmoku;

public class Koma {

}
