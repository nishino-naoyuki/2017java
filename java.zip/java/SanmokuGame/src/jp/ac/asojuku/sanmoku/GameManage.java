package jp.ac.asojuku.sanmoku;

import java.util.InputMismatchException;
import java.util.Scanner;

public class GameManage {
	private final int KOMA_NOTHING = 0;
	private final int KOMA_MARU = 1;
	private final int KOMA_BATSU = 2;
	private final int BANX = 3;
	private final int BANY = 3;

	private int[][] ban = new int[BANY][BANX];
	private boolean isTurnSente;
	/**
	 * ゲーム処理
	 * @param s
	 */
	public void gameMain(Scanner s){

		boolean bFinish = false;

		//初期化を行う
		initial();

		isTurnSente = true;	//先手から
		while( bFinish == false ){
			//画面表示
			display();
			//入力
			if( input(s) == false ){
				continue;
			}
			//チェック
			bFinish = isGameEnd();

			//先手・後手交代
			isTurnSente = !isTurnSente;
		}
		//画面表示
		display();
	}

	/**
	 * 初期化を行う
	 */
	private void initial(){
		for(int i = 0; i < BANX; i++ ){
			for( int j = 0; j < BANY; j++){
				ban[j][i] = KOMA_NOTHING;
			}
		}
	}

	/**
	 * コマを表示する
	 */
	private void display(){

		System.out.println("－－－－－");
		for(int y = 0; y < BANX; y++ ){
			System.out.print("|");
			for( int x = 0; x < BANY; x++){
				//map配列に入っている内容で表示を変える
				if( ban[y][x] == KOMA_MARU){
					System.out.print("○");
				}else if( ban[y][x] == KOMA_BATSU ){
					System.out.print("×");
				}else{
					System.out.print("　");
				}
				System.out.print("|");
			}
			System.out.println();
			System.out.println("－－－－－");
		}

	}

	/**
	 * 入力処理
	 * @param s
	 * @return
	 */
	private boolean input(Scanner s){
		boolean bInputOK = false;
		try{
			if( isTurnSente ){
				System.out.println("先手入力してください（１～３）");
			}else{
				System.out.println("後手入力してください（１～３）");
			}

			System.out.print("x=");
			int x = s.nextInt();
			System.out.print("y=");
			int y = s.nextInt();

			//エラーチェック
			if( isInputCheckOK(x,y) != true ){
				return false;
			}

			x--;
			y--;
			ban[y][x] = (isTurnSente ? KOMA_MARU:KOMA_BATSU);

			bInputOK = true;
		}catch(InputMismatchException  e){
			System.out.println("数値入力しろ！");
			s.next();
		}

		return bInputOK;
	}

	/**
	 * 入力チェック
	 * @param x
	 * @param y
	 * @return
	 */
	private boolean isInputCheckOK(int x,int y){

		//範囲チェック
		if(
			( x < 1 || x > 3 ) ||
			( y < 1 || y > 3 )
		  ){

			System.out.println("１～３の間で入力してください");
			return false;
		}

		//既にコマがあるかのチェック
		x--;
		y--;

		if( ban[y][x] != KOMA_NOTHING){
			System.out.println("既にコマが置いてあります。他の所に打ってください");
			return false;
		}

		return true;
	}

	/**
	 * ゲームの終了をチェックする
	 * @return
	 */
	private boolean isGameEnd(){
		//縦に並んだかのチェック
		if( isOKVirtical() ){
			return true;
		}

		//横に並んだかのチェック
		if( isOKHorizen() ){
			return true;
		}

		//ナナメに並んだかのチェック
		if( isOKDiagonally() ){
			return true;
		}

		//引き分けチェック
		if( isEven() ){
			System.out.println("引き分けです");
			return true;
		}

		return false;
	}

	/**
	 * 引き分けチェック
	 * @return
	 */
	private boolean isEven(){
		int blankCount = 0;

		for(int y = 0; y < BANX; y++ ){
			for( int x = 0; x < BANY; x++){
				if( ban[y][x] != KOMA_NOTHING){
					blankCount++;
				}
			}
		}

		return (blankCount == (BANX*BANY) ? true:false);
	}

	/**
	 * 縦に並んだかのチェック
	 * @return
	 */
	private boolean isOKVirtical(){
		int base = KOMA_NOTHING;
		boolean isOK = false;

		for(int x = 0; x < BANX && isOK == false ; x++ ){
			//基準となるこまを取得
			base = ban[0][x];
			if( base == KOMA_NOTHING){
				//こまがないならチェック不要
				continue;
			}
			isOK = true;
			//基準と一致するかどうかを縦方向にチェック
			for(int y = 1; y < BANY; y++){
				if( base != ban[y][x]){
					isOK = false;
					break;
				}
			}
		}

		if( isOK ){
			String koma = (base == KOMA_MARU ? "先手":"後手");
			System.out.println(koma+"の勝利です");
		}

		return isOK;
	}

	/**
	 * 縦に並んだかのチェック
	 * @return
	 */
	private boolean isOKHorizen(){
		int base = KOMA_NOTHING;
		boolean isOK = false;

		for(int y = 0; y < BANY && isOK == false ; y++ ){
			//基準となるこまを取得
			base = ban[y][0];
			if( base == KOMA_NOTHING){
				//こまがないならチェック不要
				continue;
			}
			isOK = true;
			//基準と一致するかどうかを縦方向にチェック
			for(int x = 1; x < BANX; x++){
				if( base != ban[y][x]){
					isOK = false;
					break;
				}
			}
		}

		if( isOK ){
			String koma = (base == KOMA_MARU ? "先手":"後手");
			System.out.println(koma+"の勝利です");
		}

		return isOK;
	}

	/**
	 * ナナメに並んだかのチェック
	 * @return
	 */
	private boolean isOKDiagonally(){
		int base = KOMA_NOTHING;
		boolean isOK = false;

		//基準となる位置（左上と右上）
		int[][] basePt = {
				{0,0},		//基準値：左上
				{0,BANX-1}	//基準値：右上
			};

		for( int b = 0; b < basePt.length; b++ ){
			//基準を取得
			int by = basePt[b][0];
			int bx = basePt[b][1];
			base = ban[by][bx];

			if( base != KOMA_NOTHING){
				//コマがあるならチェック開始
				isOK = true;
				for( int i = 1; i < BANY; i++ ){
					if( base != ban[i][Math.abs(bx-i)]){
						isOK = false;
						break;
					}
				}
			}

			if( isOK ){
				String koma = (base == KOMA_MARU ? "先手":"後手");
				System.out.println(koma+"の勝利です");
				break;
			}
		}

		return isOK;
	}
}
