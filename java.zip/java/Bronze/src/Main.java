 interface A{
	 void aa();
}

public class Main {

	public static void main(String[] args) {

	}

}

//このコードを実行すると、どうなるか１つ選べ
//
//A.69と表示される
//B.56と表示される
//C.59と表示される
//D.66と表示される




